# lwip_sql_connector
this is an ongoing  project for a lwip mySQL connector based on TCP RAW API.<br>
The seed for this project was an Arduino based mySQL connector called "MySQL_Connector_Arduino" by "ChuckBell"
link: https://github.com/ChuckBell/MySQL_Connector_Arduino

## Sponsored by

<a href = "https://the-diy-life.co">
<img src="https://the-diy-life.co/images/logo_diylife.jpg"  width="248" height="248">
</a>
